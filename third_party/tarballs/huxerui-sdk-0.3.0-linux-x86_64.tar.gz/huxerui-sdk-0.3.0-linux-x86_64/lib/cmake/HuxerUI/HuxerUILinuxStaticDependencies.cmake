include(CMakeFindDependencyMacro)

find_dependency(PkgConfig)
pkg_check_modules(HUXERUI_GTK4 REQUIRED IMPORTED_TARGET gtk4>=4.14)
pkg_check_modules(HUXERUI_EPOXY REQUIRED IMPORTED_TARGET epoxy>=1.5)
pkg_check_modules(HUXERUI_GIO REQUIRED IMPORTED_TARGET gio-2.0)
pkg_check_modules(HUXERUI_LIBSOUP REQUIRED IMPORTED_TARGET libsoup-3.0>=3.0)
