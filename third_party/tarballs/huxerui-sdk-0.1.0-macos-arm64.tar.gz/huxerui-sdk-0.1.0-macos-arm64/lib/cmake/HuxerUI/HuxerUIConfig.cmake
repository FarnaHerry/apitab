
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was HuxerUIConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(HUXERUI_HOST_TOOL_ROOT "${PACKAGE_PREFIX_DIR}/share/huxerui/tools")
set_and_check(HUXERUI_BUILTIN_RESOURCE_PACKAGE
        "${PACKAGE_PREFIX_DIR}/share/huxerui/resources"
)

set(_HUXERUI_WANT_SHARED FALSE)
set(_HUXERUI_WANT_STATIC FALSE)
if (HuxerUI_FIND_COMPONENTS)
    foreach (_HUXERUI_COMPONENT IN LISTS HuxerUI_FIND_COMPONENTS)
        if (_HUXERUI_COMPONENT STREQUAL "shared")
            set(_HUXERUI_WANT_SHARED TRUE)
        elseif (_HUXERUI_COMPONENT STREQUAL "static")
            set(_HUXERUI_WANT_STATIC TRUE)
        endif ()
    endforeach ()
elseif (ANDROID)
    set(_HUXERUI_WANT_SHARED TRUE)
elseif (EMSCRIPTEN OR IOS)
    set(_HUXERUI_WANT_STATIC TRUE)
else ()
    set(_HUXERUI_WANT_SHARED ON)
    set(_HUXERUI_WANT_STATIC ON)
endif ()

if (IOS)
    if (_HUXERUI_WANT_STATIC)
        set_and_check(_HUXERUI_IOS_XCFRAMEWORK
                "${PACKAGE_PREFIX_DIR}/share/huxerui/platform/ios/HuxerUI.xcframework"
        )
        string(TOLOWER "${CMAKE_OSX_SYSROOT}" _HUXERUI_IOS_SYSROOT)
        if (_HUXERUI_IOS_SYSROOT MATCHES "simulator")
            set(_HUXERUI_IOS_SLICE "ios-arm64_x86_64-simulator")
        else ()
            set(_HUXERUI_IOS_SLICE "ios-arm64")
        endif ()
        set_and_check(_HUXERUI_IOS_LIBRARY
                "${_HUXERUI_IOS_XCFRAMEWORK}/${_HUXERUI_IOS_SLICE}/libhuxerui_static.a"
        )
        set(_HUXERUI_IOS_LINK_LIBRARIES
                "-framework CoreFoundation"
                "-framework CoreGraphics"
                "-framework CoreImage"
                "-framework CoreText"
                "-framework CoreVideo"
                "-framework Foundation"
                "-framework ImageIO"
                "-framework MobileCoreServices"
                "-framework QuartzCore"
                "-framework UIKit"
                "-weak_framework UniformTypeIdentifiers"
        )
        foreach (_HUXERUI_IOS_TARGET IN ITEMS HuxerUI::huxerui HuxerUI::huxerui_static)
            if (TARGET ${_HUXERUI_IOS_TARGET})
                continue()
            endif ()
            add_library(${_HUXERUI_IOS_TARGET} STATIC IMPORTED)
            set_target_properties(${_HUXERUI_IOS_TARGET} PROPERTIES
                    IMPORTED_LOCATION "${_HUXERUI_IOS_LIBRARY}"
                    INTERFACE_INCLUDE_DIRECTORIES "${PACKAGE_PREFIX_DIR}/include"
                    INTERFACE_LINK_LIBRARIES "${_HUXERUI_IOS_LINK_LIBRARIES}"
            )
        endforeach ()
    endif ()
elseif (ANDROID)
    if (NOT ANDROID_ABI)
        message(FATAL_ERROR "HuxerUI Android package requires ANDROID_ABI")
    endif ()
    if (_HUXERUI_WANT_SHARED)
        set_and_check(HUXERUI_ANDROID_SHARED_LIBRARY
                "${PACKAGE_PREFIX_DIR}/share/huxerui/platform/android/${ANDROID_ABI}/libhuxerui.so"
        )
        if (NOT TARGET HuxerUI::huxerui)
            add_library(HuxerUI::huxerui SHARED IMPORTED)
            set_target_properties(HuxerUI::huxerui PROPERTIES
                    IMPORTED_LOCATION "${HUXERUI_ANDROID_SHARED_LIBRARY}"
                    INTERFACE_INCLUDE_DIRECTORIES "${PACKAGE_PREFIX_DIR}/include"
            )
        endif ()
    endif ()
elseif (EMSCRIPTEN)
    if (_HUXERUI_WANT_STATIC)
        set_and_check(HUXERUI_WEB_LIBRARY
                "${PACKAGE_PREFIX_DIR}/share/huxerui/platform/web/emscripten-4.0.19/libhuxerui.a"
        )
        foreach (_HUXERUI_WEB_TARGET IN ITEMS HuxerUI::huxerui HuxerUI::huxerui_static)
            if (TARGET ${_HUXERUI_WEB_TARGET})
                continue()
            endif ()
            add_library(${_HUXERUI_WEB_TARGET} STATIC IMPORTED)
            set_target_properties(${_HUXERUI_WEB_TARGET} PROPERTIES
                    IMPORTED_LOCATION "${HUXERUI_WEB_LIBRARY}"
                    INTERFACE_COMPILE_OPTIONS -fexceptions
                    INTERFACE_INCLUDE_DIRECTORIES "${PACKAGE_PREFIX_DIR}/include"
                    INTERFACE_LINK_OPTIONS
                    "--bind;--no-entry;--pre-js;${CMAKE_CURRENT_LIST_DIR}/HuxerUIWebFileSystem.js;-fexceptions;-lidbfs.js;-sMODULARIZE=1;-sEXPORT_ES6=1;-sEXPORT_NAME=createHuxerUIApp;-sEXPORTED_RUNTIME_METHODS=stringToNewUTF8;-sENVIRONMENT=web;-sALLOW_MEMORY_GROWTH=1;-sSTACK_SIZE=1048576;-sNO_EXIT_RUNTIME=1"
                    INTERFACE_LINK_DEPENDS "${CMAKE_CURRENT_LIST_DIR}/HuxerUIWebFileSystem.js"
            )
        endforeach ()
    endif ()
else ()
    if (CMAKE_SIZEOF_VOID_P AND NOT CMAKE_SIZEOF_VOID_P STREQUAL "8")
        message(FATAL_ERROR
                "HuxerUI SDK host libraries use a 8-byte pointer model, "
                "but the consuming target uses ${CMAKE_SIZEOF_VOID_P} bytes"
        )
    endif ()
    if (_HUXERUI_WANT_SHARED AND ON AND NOT TARGET HuxerUI::huxerui)
        include("${CMAKE_CURRENT_LIST_DIR}/HuxerUISharedTargets.cmake")
    endif ()
    if (_HUXERUI_WANT_STATIC AND ON AND NOT TARGET HuxerUI::huxerui_static)
        if (CMAKE_SYSTEM_NAME STREQUAL "Linux")
            include("${CMAKE_CURRENT_LIST_DIR}/HuxerUILinuxStaticDependencies.cmake")
        endif ()
        include("${CMAKE_CURRENT_LIST_DIR}/HuxerUIStaticTargets.cmake")
    endif ()
endif ()

foreach (_HUXERUI_TARGET IN ITEMS HuxerUI::huxerui HuxerUI::huxerui_static)
    if (TARGET ${_HUXERUI_TARGET})
        set_target_properties(${_HUXERUI_TARGET} PROPERTIES
                HUXERUI_RESOURCE_PACKAGE "${HUXERUI_BUILTIN_RESOURCE_PACKAGE}"
        )
    endif ()
endforeach ()

foreach (_HUXERUI_COMPONENT IN LISTS HuxerUI_FIND_COMPONENTS)
    if (_HUXERUI_COMPONENT STREQUAL "shared" AND TARGET HuxerUI::huxerui)
        set(HuxerUI_shared_FOUND TRUE)
    elseif (_HUXERUI_COMPONENT STREQUAL "static" AND TARGET HuxerUI::huxerui_static)
        set(HuxerUI_static_FOUND TRUE)
    endif ()
endforeach ()

include("${CMAKE_CURRENT_LIST_DIR}/HuxerUICodegen.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/HuxerUIResources.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/HuxerUILibraries.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/HuxerUIApp.cmake")

check_required_components(HuxerUI)

unset(_HUXERUI_COMPONENT)
unset(_HUXERUI_IOS_LIBRARY)
unset(_HUXERUI_IOS_LINK_LIBRARIES)
unset(_HUXERUI_IOS_SLICE)
unset(_HUXERUI_IOS_SYSROOT)
unset(_HUXERUI_IOS_TARGET)
unset(_HUXERUI_IOS_XCFRAMEWORK)
unset(_HUXERUI_TARGET)
unset(_HUXERUI_WANT_SHARED)
unset(_HUXERUI_WANT_STATIC)
unset(_HUXERUI_WEB_TARGET)
